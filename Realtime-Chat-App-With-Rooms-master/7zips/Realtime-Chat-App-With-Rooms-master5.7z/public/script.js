const eventNames = {
  ['new-user']: 'new-user',
  ['room-created']: 'room-created',
  ['user-connected']: 'user-connected',
  ['send-chat-message']: 'send-chat-message',
  ['chat-message']: 'chat-message',
  ['user-disconnected']: 'user-disconnected'
};

const socket = io('http://localhost:3000');
const messageContainer = document.getElementById('message-container');
const roomContainer = document.getElementById('room-container');
const messageForm = document.getElementById('send-container');
const messageInput = document.getElementById('message-input');

if (messageForm != null) {
  const name = prompt('What is your name?');
  appendMessage('You joined');
  socket.emit(eventNames['new-user'], roomName, name);

  messageForm.addEventListener('submit', e => {
    e.preventDefault();
    const message = messageInput.value;
    appendMessage(`You: ${message}`);
    socket.emit(eventNames['send-chat-message'], roomName, message);
    messageInput.value = ''
  })
}

socket.on(eventNames['room-created'], room => {
  const roomElement = document.createElement('div');
  roomElement.innerText = room;
  const roomLink = document.createElement('a');
  roomLink.href = `/${room}`;
  roomLink.innerText = 'join';
  roomContainer.append(roomElement);
  roomContainer.append(roomLink)
});

socket.on(eventNames['chat-message'], data => {
  appendMessage(`${data.name}: ${data.message}`)
});

socket.on(eventNames['user-connected'], name => {
  appendMessage(`${name} connected`)
});

socket.on(eventNames['user-disconnected'], name => {
  appendMessage(`${name} disconnected`)
});

function appendMessage(message) {
  const messageElement = document.createElement('div');
  messageElement.innerText = message;
  messageContainer.append(messageElement)
}

function ntsTestThisIsNotBundled(){
  console.log("this_should_not_be_bundled")
}
