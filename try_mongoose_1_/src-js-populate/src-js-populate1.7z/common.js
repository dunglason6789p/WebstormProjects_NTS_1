module.exports.handleError = function(err) {
    console.log(err);
};
