/*
 *  /MathJax/fonts/HTML-CSS/TeX/png/Main/Bold/LatinExtendedB.js
 *  
 *  Copyright (c) 2010-2013 The MathJax Consortium
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.OutputJax["HTML-CSS"].defineImageData({"MathJax_Main-bold":{567:[[4,4,1],[5,6,2],[6,7,2],[6,7,2],[7,9,3],[8,11,3],[10,13,4],[11,16,5],[13,19,6],[15,21,6],[18,26,8],[21,30,9],[25,36,11],[29,43,13]]}});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].imgDir+"/Main/Bold"+MathJax.OutputJax["HTML-CSS"].imgPacked+"/LatinExtendedB.js");

